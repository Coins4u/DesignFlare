import { Navbar } from '../components/Navbar';
import { Hero } from '../components/Hero';
import { LogoCloud } from '../components/LogoCloud';
import { FeatureGrid } from '../components/FeatureGrid';
import { Pricing } from '../components/Pricing';
import { Testimonials } from '../components/Testimonials';
import { LeadForm } from '../components/LeadForm';
import { Footer } from '../components/Footer';

export default function HealthcarePortalPage() {
  return (
    <>
      <Navbar brand="Healthcare Portal" />
      <main>
        <Hero framework="Healthcare Portal" />
        <LogoCloud />
        <FeatureGrid />
        <Testimonials />
        <Pricing />
        <LeadForm apiRoute="/api/healthcare-portal" />
      </main>
      <Footer brand="Healthcare Portal" />
    </>
  );
}
