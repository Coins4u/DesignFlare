# Bonus utility 5

Part of Complete Marketing (160+ assets).

Reusable snippet for Enterprise Agency Suite tier.
