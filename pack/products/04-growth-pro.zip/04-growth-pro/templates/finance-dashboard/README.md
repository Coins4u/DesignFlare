# Finance Dashboard

## Stack
Next.js 14 · React 18 · Tailwind CSS 3 · TypeScript

## Quick start
```bash
cp -r . your-project/
cd your-project && npm install && npm run dev
```

## API
`POST /api/finance-dashboard` — validated lead capture with rate limiting
